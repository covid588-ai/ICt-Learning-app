# ICT Learning — Android Studio ছাড়া APK বানানোর প্রজেক্ট

এটি ব্যবহারকারীর দেওয়া `app.zip`-এর **বিকল্প হিসেবে নতুন, সহজ Native Android Java starter project**। মূল ZIP একটি Android demo ছিল, সম্পূর্ণ ICT অ্যাপ নয়।

## বর্তমানে যা আছে

- **ICT → Python Programming → ১২টি টপিক → ১৩টি ভিডিও**
- সব Google Drive video ID অন্তর্ভুক্ত, টপিক ৮-এ দুটি ভিডিও
- মোবাইল-ফ্রেন্ডলি বাংলা UI ও বিষয়/অধ্যায়/টপিক নেভিগেশন
- ভিডিওতে চাপলে অ্যাপের ভেতরে Google Drive `/preview` WebView চেষ্টা করে
- Restricted ভিডিওতে অনুমতি না থাকলে Google Drive-এর নিজস্ব নিয়ম প্রযোজ্য
- প্রয়োজনে Google Drive অ্যাপে খোলার বিকল্প

## যা এখনও নেই (গুরুত্বপূর্ণ)

- এটি **পরীক্ষিত APK নয়**, APK build করার উপযোগী একটি সোর্স প্রজেক্ট।
- Private Google OAuth/API-based streaming backend **নেই**। Restricted ভিডিও embedded WebView-এ নাও চলতে পারে; ব্রাউজারে/Drive অ্যাপে অ্যাক্সেস দেওয়া অ্যাকাউন্ট দিয়ে খুলতে হতে পারে।
- Admin dashboard, Google Sign-In, protected private proxy, PDF viewer, dynamic database, bookmarks **এখনও তৈরি হয়নি**। PDF কোনো লিংক দেওয়া হয়নি।
- Link UI-তে দেখানো হয় না, কিন্তু network inspector থেকে সম্পূর্ণ গোপন রাখা যায় না।

## GitHub Actions দিয়ে APK তৈরি (Android Studio ছাড়াই)

1. GitHub-এ নতুন **public বা private** repository তৈরি করুন।
2. এই ZIP extract করে ফাইলগুলো (লুকানো `.github` ফোল্ডারসহ) repository-এর **root**-এ আপলোড করুন।
3. GitHub-এ **Actions** ট্যাবে যান।
4. `Build ICT Learning APK` workflow খুলুন, **Run workflow** চাপুন। `main`-এ push করলে auto-run-ও হতে পারে।
5. সফল হলে run-এর **Artifacts → ICT-Learning-APK** থেকে ZIP ডাউনলোড করুন; তার ভেতরে `app-debug.apk` পাবেন।
6. APK Android ফোনে ইনস্টল করুন (প্রয়োজনে Chrome/Files-এর Install unknown apps অনুমতি দিন)।

**Debug APK** testing-এর জন্য; Google Play Store-এ প্রকাশ করতে signed release AAB এবং signing key প্রয়োজন।

### GitHub folder structure

```
.github/workflows/build-apk.yml
app/src/main/java/bd/edu/ictlearning/MainActivity.java
app/src/main/AndroidManifest.xml
app/src/main/res/drawable/app_icon.png
app/src/main/res/values/strings.xml
app/build.gradle.kts
build.gradle.kts
settings.gradle.kts
gradle.properties
gradle/wrapper/gradle-wrapper.properties
```

Github Actions-এ preinstalled Java এবং Gradle 8.6 ব্যবহার হওয়ায়, এই প্রজেক্টে `gradlew` বা Gradle wrapper JAR ছাড়াও build চলার কথা।

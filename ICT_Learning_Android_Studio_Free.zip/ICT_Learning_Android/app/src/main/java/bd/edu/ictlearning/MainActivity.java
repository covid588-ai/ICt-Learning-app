package bd.edu.ictlearning;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Offline course catalog + in-app Google Drive preview starter.
 * Google Drive itself enforces file permissions. This project does NOT implement
 * secure native Google OAuth, an authenticated media proxy, or an admin backend.
 */
public final class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(35, 84, 210);
    private static final int TEXT = Color.rgb(26, 41, 65);
    private static final int MUTED = Color.rgb(101, 117, 139);
    private static final int LIGHT = Color.rgb(245, 248, 253);

    private static final String[] TOPICS = {
        "প্রোগ্রামিং, কম্পাইলার, ইন্টারপ্রেটার",
        "চলকের ধারণা",
        "পাইথন সফটওয়্যার ইন্সটলেশন",
        "চলকের নামকরণ",
        "চলকে মান এসাইন",
        "ডাটা টাইপ",
        "টাইপকাস্টিং",
        "ইনপুট",
        "অপারেটর",
        "তুলনা",
        "if statement",
        "if-else statement"
    };
    private static final String[][] VIDEO_NAMES = {
        {"ভিডিও লেকচার"}, {"ভিডিও লেকচার"}, {"ভিডিও লেকচার"},
        {"ভিডিও লেকচার"}, {"ভিডিও লেকচার"}, {"ভিডিও লেকচার"},
        {"ভিডিও লেকচার"}, {"ইনপুট-১", "ইনপুট-২"},
        {"ভিডিও লেকচার"}, {"ভিডিও লেকচার"},
        {"ভিডিও লেকচার"}, {"ভিডিও লেকচার"}
    };
    private static final String[][] VIDEO_IDS = {
        {"1UKAu7CkpJ0CApLJ_ul3HP1D89AhRHeQC"},
        {"19Q9LDqtGosgYCj6LEtF2HSddH07xvzaX"},
        {"1yacwJ0x8wJvdQCah8CcE9dBFqV5kZW6r"},
        {"1feTGVcj8xYEYE_fPn5l9P0CTJ5Yyqrzc"},
        {"1Mfpb1t7HMorhowaIpSVjzT-9EDfJdcjS"},
        {"1yfOn0Atug-LsDFgKDJs1gKmq8a-sVH2N"},
        {"1EYgkqC2SoZHO4UbXuqfkfeSdBpkfcqvP"},
        {"1TC0Snk4m03UYsqv8oQj69muKS6qgKWyJ", "1ZCzbIAvHfFX_gBVmxo0yFqW-tHCSKTbX"},
        {"1PBWTBJNMJlvUAQcaf--TLa8_2HoGSEs1"},
        {"1ZKVGv3npnemUi9_tkOncGEpLVIq7d-e6"},
        {"16J6eBTH6jV_1Lp_4JjKg3MoTYvM6pgFS"},
        {"1MBF40Q7z5pMOjWsc8RPf6gvFvjzTARN5"}
    };

    private enum Page { HOME, CHAPTERS, TOPICS, MATERIALS, VIDEO }
    private Page page = Page.HOME;
    private int selectedTopic = -1;
    private int selectedVideo = -1;
    private LinearLayout root;
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(22, 62, 164));
        showHome();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private LinearLayout vertical(int padding) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(padding), dp(padding), dp(padding), dp(padding));
        return v;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(dp(3), 1f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void startScreen(String heading, boolean back) {
        stopPlayer();
        root = vertical(0);
        root.setBackgroundColor(LIGHT);
        setContentView(root);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(14), dp(14), dp(14));
        bar.setBackgroundColor(BLUE);
        if (back) {
            TextView arrow = text("‹", 34, Color.WHITE, true);
            arrow.setGravity(Gravity.CENTER);
            arrow.setWidth(dp(42));
            arrow.setOnClickListener(v -> onBackPressed());
            bar.addView(arrow);
        }
        TextView title = text(heading, 21, Color.WHITE, true);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(64)));
    }

    private LinearLayout content() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = vertical(16);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return content;
    }

    private void subtitle(LinearLayout parent, String message) {
        TextView t = text(message, 14, MUTED, false);
        t.setPadding(0, dp(4), 0, dp(20));
        parent.addView(t);
    }

    private void card(LinearLayout parent, String title, String detail, Runnable action) {
        LinearLayout item = vertical(16);
        item.setBackground(bg(Color.WHITE, 14));
        TextView t = text(title, 17, TEXT, true);
        item.addView(t);
        TextView sub = text(detail, 13, MUTED, false);
        sub.setPadding(0, dp(6), 0, 0);
        item.addView(sub);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        parent.addView(item, lp);
        if (action != null) {
            item.setClickable(true);
            item.setFocusable(true);
            item.setOnClickListener(v -> action.run());
        }
    }

    private void showHome() {
        page = Page.HOME;
        startScreen("ICT Learning", false);
        LinearLayout body = content();
        TextView hi = text("স্বাগতম! 📚", 25, TEXT, true);
        hi.setPadding(0, dp(6), 0, dp(4));
        body.addView(hi);
        subtitle(body, "বিষয়, অধ্যায় ও টপিক অনুযায়ী ভিডিও লেকচার দেখুন।");
        card(body, "ICT", "১টি অধ্যায় • ১২টি টপিক • ১৩টি ভিডিও", this::showChapters);
        card(body, "নোট", "PDF যুক্ত করার ব্যবস্থা পরবর্তী সংস্করণে আসবে।", null);
        subtitle(body, "এটি অফলাইন বিষয় তালিকাসহ Google Drive Preview-ভিত্তিক প্রাথমিক সংস্করণ।");
    }

    private void showChapters() {
        page = Page.CHAPTERS;
        startScreen("ICT • অধ্যায়", true);
        LinearLayout body = content();
        subtitle(body, "ICT বিষয়ের অধ্যায় নির্বাচন করুন");
        card(body, "Python Programming", "১২টি টপিক • ১৩টি ভিডিও", this::showTopics);
    }

    private void showTopics() {
        page = Page.TOPICS;
        startScreen("Python Programming", true);
        LinearLayout body = content();
        subtitle(body, "টপিক নির্বাচন করুন");
        for (int i = 0; i < TOPICS.length; i++) {
            final int index = i;
            String num = String.format(java.util.Locale.US, "%02d", i + 1);
            card(body, "টপিক " + num + ": " + TOPICS[i],
                    VIDEO_IDS[i].length + "টি ভিডিও", () -> showMaterials(index));
        }
    }

    private void showMaterials(int topicIndex) {
        selectedTopic = topicIndex;
        page = Page.MATERIALS;
        startScreen("টপিক " + String.format(java.util.Locale.US, "%02d", selectedTopic + 1), true);
        LinearLayout body = content();
        TextView topic = text(TOPICS[selectedTopic], 22, TEXT, true);
        body.addView(topic);
        subtitle(body, "ভিডিওতে চাপলে অ্যাপের ভিতরে Google Drive Preview খোলার চেষ্টা করবে।");
        for (int j = 0; j < VIDEO_IDS[selectedTopic].length; j++) {
            final int videoIndex = j;
            String name = VIDEO_NAMES[selectedTopic][j];
            card(body, "▶  " + name, "Google Drive ভিডিও", () -> showVideo(videoIndex));
        }
        card(body, "📄  PDF Notes", "এই টপিকের PDF এখনো দেওয়া হয়নি", null);
    }

    private void showVideo(int videoIndex) {
        selectedVideo = videoIndex;
        page = Page.VIDEO;
        startScreen(VIDEO_NAMES[selectedTopic][videoIndex], true);
        String fileId = VIDEO_IDS[selectedTopic][videoIndex];
        String previewUrl = "https://drive.google.com/file/d/" + fileId + "/preview";
        LinearLayout banner = vertical(12);
        banner.setBackgroundColor(Color.WHITE);
        banner.addView(text("Private Google Drive ভিডিও হলে আপনার Google Account-এ ফাইলটির Access থাকতে হবে। Google লগইন embedded WebView-এ নাও চলতে পারে।", 13, TEXT, false));
        root.addView(banner);

        FrameLayout viewer = new FrameLayout(this);
        viewer.setBackgroundColor(Color.BLACK);
        root.addView(viewer, new LinearLayout.LayoutParams(-1, 0, 1));
        ProgressBar spinner = new ProgressBar(this);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.CENTER);
        viewer.addView(spinner, sp);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                spinner.setVisibility(View.GONE);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        viewer.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        webView.loadUrl(previewUrl);
        LinearLayout actions = vertical(10);
        actions.setBackgroundColor(Color.WHITE);
        TextView help = text("ভিডিও না চললে Google Drive অ্যাপে ফাইলটি খুলে দেখুন। Restricted ফাইলের অনুমতি Drive-এ দেওয়া থাকতে হবে।", 12, MUTED, false);
        actions.addView(help);
        Button external = new Button(this);
        external.setText("Google Drive-এ খুলুন (বিকল্প)");
        external.setAllCaps(false);
        external.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://drive.google.com/file/d/" + fileId + "/view"));
            try { startActivity(intent); }
            catch (ActivityNotFoundException ignored) {
                android.widget.Toast.makeText(this, "ব্রাউজার পাওয়া যায়নি", android.widget.Toast.LENGTH_LONG).show();
            }
        });
        actions.addView(external, new LinearLayout.LayoutParams(-1, dp(54)));
        root.addView(actions);
    }

    private void stopPlayer() {
        if (webView != null) {
            WebView old = webView;
            webView = null;
            old.stopLoading();
            old.loadUrl("about:blank");
            if (old.getParent() instanceof ViewGroup) ((ViewGroup) old.getParent()).removeView(old);
            old.destroy();
        }
    }

    @Override public void onBackPressed() {
        if (page == Page.VIDEO) showMaterials(selectedTopic);
        else if (page == Page.MATERIALS) showTopics();
        else if (page == Page.TOPICS) showChapters();
        else if (page == Page.CHAPTERS) showHome();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        stopPlayer();
        super.onDestroy();
    }
}

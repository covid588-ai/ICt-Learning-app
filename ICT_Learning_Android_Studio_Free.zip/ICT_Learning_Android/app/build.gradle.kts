plugins { id("com.android.application") }

android {
    namespace = "bd.edu.ictlearning"
    compileSdk = 34

    defaultConfig {
        applicationId = "bd.edu.ictlearning"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-starter"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
